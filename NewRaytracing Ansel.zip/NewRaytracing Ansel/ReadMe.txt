	WARNING!

	This product need to be used carefuly because inside of this product 
	have heavy's filters that can cause serious damage.


	Requeriments:

	GTX 1660 Super or GTX 1660 Ti upper
	GTX 1060 6GB, GTX 1070, GTX 1080, GTX 1080 Ti Upper: Pascal generation 
	cards.

	This product is recommended to be used on this graphics card:

	RTX 2030 Upper, or, RTX 2030 TI Upper.

	If you didn't have the listed graphics cards that are listed up
	and you get damages our team are not responsabilised.